#ifndef HW2_VERTEX_H
#define HW2_VERTEX_H

#include "global.h"

struct Vertex {
    vec3 pos;
    vec3 nor;
    vec2 tex;
    vec3 tan;
};
typedef GLushort Index;

#endif //HW2_VERTEX_H
